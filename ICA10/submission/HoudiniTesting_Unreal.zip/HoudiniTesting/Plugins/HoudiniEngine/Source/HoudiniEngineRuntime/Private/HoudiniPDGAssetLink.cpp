/*
* Copyright (c) <2021> Side Effects Software Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. The name of Side Effects Software may not be used to endorse or
*    promote products derived from this software without specific prior
*    written permission.
*
* THIS SOFTWARE IS PROVIDED BY SIDE EFFECTS SOFTWARE "AS IS" AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
* NO EVENT SHALL SIDE EFFECTS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "HoudiniPDGAssetLink.h"

#include "HoudiniEngineRuntime.h"
#include "HoudiniEngineRuntimePrivatePCH.h"
#include "HoudiniEngineRuntimeUtils.h"
#include "HoudiniLandscapeRuntimeUtils.h"
#include "HoudiniOutput.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "GameFramework/Actor.h"
#include "InstancedFoliageActor.h"
#include "Landscape.h"
#include "UObject/MetaData.h"

#if WITH_EDITOR
	#include "FileHelpers.h"
	#include "EditorModeManager.h"
	#include "EditorModes.h"
#endif

//
UHoudiniPDGAssetLink::UHoudiniPDGAssetLink(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, AssetName()
	, AssetNodePath()
	, AssetID(-1)
	, SelectedTOPNetworkIndex(-1)
	, LinkState(EPDGLinkState::Inactive)
	, bAutoCook(false)
	, bUseTOPNodeFilter(true)
	, bUseTOPOutputFilter(true)
	, NumWorkItems(0)
	, WorkItemTally()
	, OutputCachePath()
	, bNeedsUIRefresh(false)
	, OutputParentActor(nullptr)
	, NumAttemptedNodeAutoBakes(0)
	, NumSuccessfulNodeAutoBakes(0)
{
	TOPNodeFilter = HAPI_UNREAL_PDG_DEFAULT_TOP_FILTER;
	TOPOutputFilter = HAPI_UNREAL_PDG_DEFAULT_TOP_OUTPUT_FILTER;

#if WITH_EDITORONLY_DATA
	bBakeMenuExpanded = true;
	HoudiniEngineBakeOption = EHoudiniEngineBakeOption::ToActor;
	PDGBakeSelectionOption = EPDGBakeSelectionOption::All;
	PDGBakePackageReplaceMode = EPDGBakePackageReplaceModeOption::ReplaceExistingAssets;
	bRecenterBakedActors = false;
	bBakeAfterAllWorkResultObjectsLoaded = false;
	bAutoBakeNodesWithFailedWorkItems = true;
#endif
	
	// Folder used for baking PDG outputs
	BakeFolder.Path = HAPI_UNREAL_DEFAULT_BAKE_FOLDER;

	// TODO:
	// Update init, move default filter to PCH
}

FTOPWorkResultObject::FTOPWorkResultObject()
{
	// ResultObjects = nullptr;
	Name = FString();
	FilePath = FString();
	State = EPDGWorkResultState::None;
	WorkItemResultInfoIndex = INDEX_NONE;
	bAutoBakedSinceLastLoad = false;
	WorkItemId = INDEX_NONE;
	TOPNode = nullptr;
}

FTOPWorkResultObject::~FTOPWorkResultObject()
{
	// DestroyResultOutputs();
}

FTOPWorkResult::FTOPWorkResult()
{
	WorkItemIndex = -1;
	WorkItemID = -1;

	ResultObjects.SetNum(0);
}

bool 
FTOPWorkResult::operator==(const FTOPWorkResult& OtherWorkResult) const
{
	if (WorkItemIndex != OtherWorkResult.WorkItemIndex)
		return false;
	if (WorkItemID != OtherWorkResult.WorkItemID)
		return false;
	/*
	if (ResultObjects != OtherWorkResult.ResultObjects)
		return false;
	*/

	return true;
}

void
FTOPWorkResult::ClearAndDestroyResultObjects(const FGuid& InHoudiniComponentGuid)
{
	if (ResultObjects.Num() <= 0)
		return;

	for (FTOPWorkResultObject& ResultObject : ResultObjects)
	{
		ResultObject.DestroyResultOutputsAndRemoveOutputActor(InHoudiniComponentGuid);
	}
	
	ResultObjects.Empty();
}

int32 
FTOPWorkResult::IndexOfWorkResultObjectByHAPIResultInfoIndex(const int32& InWorkItemResultInfoIndex)
{
	const int32 NumEntries = ResultObjects.Num();
	for (int32 Index = 0; Index < NumEntries; ++Index)
	{
		const FTOPWorkResultObject& CurResultObject = ResultObjects[Index];
		if (CurResultObject.WorkItemResultInfoIndex == InWorkItemResultInfoIndex)
		{
			return Index;
		}
	}

	return INDEX_NONE;
}

FTOPWorkResultObject*
FTOPWorkResult::GetWorkResultObjectByHAPIResultInfoIndex(const int32& InWorkItemResultInfoIndex)
{
	const int32 ArrayIndex = IndexOfWorkResultObjectByHAPIResultInfoIndex(InWorkItemResultInfoIndex);
	if (ArrayIndex == INDEX_NONE)
	{
		return nullptr;
	}
	
	return GetWorkResultObjectByArrayIndex(ArrayIndex);
}

FTOPWorkResultObject*
FTOPWorkResult::GetWorkResultObjectByArrayIndex(const int32& InArrayIndex)
{
	if (!ResultObjects.IsValidIndex(InArrayIndex))
	{
		return nullptr;
	}

	return &ResultObjects[InArrayIndex];
}


FWorkItemTallyBase::~FWorkItemTallyBase()
{
}

bool
FWorkItemTallyBase::AreAllWorkItemsComplete() const
{
	return (
		NumWaitingWorkItems() == 0 && NumCookingWorkItems() == 0 && NumScheduledWorkItems() == 0 
		&& (NumWorkItems() == (NumCookedWorkItems() + NumErroredWorkItems())) );
}

bool
FWorkItemTallyBase::AnyWorkItemsFailed() const
{
	return NumErroredWorkItems() > 0;
}

bool
FWorkItemTallyBase::AnyWorkItemsPending() const
{
	return (NumWorkItems() > 0 && (NumWaitingWorkItems() > 0 || NumCookingWorkItems() > 0 || NumScheduledWorkItems() > 0));
}

FString
FWorkItemTallyBase::ProgressRatio() const
{
	const float Ratio = NumWorkItems() > 0 ? (NumCookedWorkItems() / NumWorkItems()) * 100.f : 0;

	return FString::Printf(TEXT("%.1f%%"), Ratio);
}


FWorkItemTally::FWorkItemTally()
{
	AllWorkItems.Empty();
	WaitingWorkItems.Empty();
	ScheduledWorkItems.Empty();
	CookingWorkItems.Empty();
	CookedWorkItems.Empty();
	ErroredWorkItems.Empty();
	CookCancelledWorkItems.Empty();
	LoadedWorkItems.Empty();
}

void
FWorkItemTally::ZeroAll()
{
	AllWorkItems.Empty();
	WaitingWorkItems.Empty();
	ScheduledWorkItems.Empty();
	CookingWorkItems.Empty();
	CookedWorkItems.Empty();
	ErroredWorkItems.Empty();
	CookCancelledWorkItems.Empty();
	LoadedWorkItems.Empty();
}

void 
FWorkItemTally::RemoveWorkItem(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	AllWorkItems.Remove(InWorkItemID);
}

void 
FWorkItemTally::RecordWorkItemAsWaiting(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	WaitingWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void 
FWorkItemTally::RecordWorkItemAsScheduled(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	ScheduledWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void 
FWorkItemTally::RecordWorkItemAsCooking(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	CookingWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void 
FWorkItemTally::RecordWorkItemAsCooked(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	CookedWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void
FWorkItemTally::RecordWorkItemAsLoaded(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	LoadedWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void 
FWorkItemTally::RecordWorkItemAsErrored(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	ErroredWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void 
FWorkItemTally::RecordWorkItemAsCookCancelled(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	CookCancelledWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void
FWorkItemTally::RecordWorkItemAsEmpty(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	EmptyWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}

void
FWorkItemTally::RecordWorkItemAsIgnored(int32 InWorkItemID)
{
	RemoveWorkItemFromAllStateSets(InWorkItemID);
	IgnoredWorkItems.Add(InWorkItemID);
	AllWorkItems.Add(InWorkItemID);
}


void
FWorkItemTally::RemoveWorkItemFromAllStateSets(int32 InWorkItemID)
{
	WaitingWorkItems.Remove(InWorkItemID);
	ScheduledWorkItems.Remove(InWorkItemID);
	CookingWorkItems.Remove(InWorkItemID);
	CookedWorkItems.Remove(InWorkItemID);
	ErroredWorkItems.Remove(InWorkItemID);
	CookCancelledWorkItems.Remove(InWorkItemID);
	LoadedWorkItems.Remove(InWorkItemID);
	EmptyWorkItems.Remove(InWorkItemID);
	IgnoredWorkItems.Remove(InWorkItemID);
}


FAggregatedWorkItemTally::FAggregatedWorkItemTally()
{
	ZeroAll();
}

void
FAggregatedWorkItemTally::ZeroAll()
{
	TotalWorkItems = 0;
	WaitingWorkItems = 0;
	ScheduledWorkItems = 0;
	CookingWorkItems = 0;
	CookedWorkItems = 0;
	ErroredWorkItems = 0;
	CookCancelledWorkItems = 0;
	LoadedWorkItems = 0;
	EmptyWorkItems = 0;
	IgnoredWorkItems = 0;
}

void 
FAggregatedWorkItemTally::Add(const FWorkItemTallyBase& InWorkItemTally)
{
	TotalWorkItems += InWorkItemTally.NumWorkItems();
	WaitingWorkItems += InWorkItemTally.NumWaitingWorkItems();
	ScheduledWorkItems += InWorkItemTally.NumScheduledWorkItems();
	CookingWorkItems += InWorkItemTally.NumCookingWorkItems();
	CookedWorkItems += InWorkItemTally.NumCookedWorkItems();
	ErroredWorkItems += InWorkItemTally.NumErroredWorkItems();
	CookCancelledWorkItems += InWorkItemTally.NumCookCancelledWorkItems();
	LoadedWorkItems += InWorkItemTally.NumLoadedWorkItems();
	EmptyWorkItems += InWorkItemTally.NumEmptyWorkItems();
	IgnoredWorkItems += InWorkItemTally.NumIgnoredWorkItems();
}

void 
FAggregatedWorkItemTally::Subtract(const FWorkItemTallyBase& InWorkItemTally)
{
	TotalWorkItems -= InWorkItemTally.NumWorkItems();
	WaitingWorkItems -= InWorkItemTally.NumWaitingWorkItems();
	ScheduledWorkItems -= InWorkItemTally.NumScheduledWorkItems();
	CookingWorkItems -= InWorkItemTally.NumCookingWorkItems();
	CookedWorkItems -= InWorkItemTally.NumCookedWorkItems();
	ErroredWorkItems -= InWorkItemTally.NumErroredWorkItems();
	CookCancelledWorkItems -= InWorkItemTally.NumCookCancelledWorkItems();
	LoadedWorkItems -= InWorkItemTally.NumLoadedWorkItems();
	EmptyWorkItems -= InWorkItemTally.NumEmptyWorkItems();
	IgnoredWorkItems += InWorkItemTally.NumIgnoredWorkItems();
}


UTOPNode::UTOPNode()
{
	NodeId = -1;
	NodeName = FString();
	NodePath = FString();
	ParentName = FString();

	WorkResultParent = nullptr;
	WorkResult.SetNum(0);

	bHidden = false;
	bAutoLoad = false;

	NodeState = EPDGNodeState::None;
	LoadState = EPDGLoadState::None;

	bCachedHaveNotLoadedWorkResults = false;
	bCachedHaveLoadedWorkResults = false;
	bHasChildNodes = false;
	bWorkItemsDirty = true;
	bShow = false;

	bHasReceivedCookCompleteEvent = false;

	InvalidateLandscapeCache();
}

bool
UTOPNode::operator==(const UTOPNode& Other) const
{
	if (!NodeName.Equals(Other.NodeName))
		return false;

	if (!ParentName.Equals(Other.ParentName))
		return false;

	//if (NodeId != Other.NodeId)
	//	return false;

	return true;
}

void 
UTOPNode::Reset()
{
	NodeState = EPDGNodeState::None;
	WorkItemTally.ZeroAll();
	AggregatedWorkItemTally.ZeroAll();
}

UHoudiniPDGAssetLink* UTOPNode::GetOuterAssetLink() const
{
	return GetTypedOuter<UHoudiniPDGAssetLink>();
}

void UTOPNode::SetWorkItemsDirty()
{
	bWorkItemsDirty = true;
}

void UTOPNode::EvaluateWorkItems()
{
#if 0
	if(!this->bWorkItemsDirty)
		return;
#endif

	this->bWorkItemsDirty = false;

	// If loading, and PDG has finished generating work items, see if we can move this TOP Node to the
	// "loaded" state. We cannot do this until Cooking is complete as new work items might be generated.

	if(this->LoadState == EPDGLoadState::Loading)
	{
		if(this->NodeState == EPDGNodeState::Cook_Complete)
		{
			if(!bAutoLoad)
			{
				this->LoadState = EPDGLoadState::IgnoredForLoad;
				for(auto& WI : WorkResult)
					this->WorkItemTally.RecordWorkItemAsIgnored(WI.WorkItemID);
				this->SetWorkItemsDirty();

				return;
			}

			bool bAllLoaded = true;
			for(FTOPWorkResult& Result : WorkResult)
			{
				if(Result.ResultObjects.IsEmpty())
				{
					this->WorkItemTally.RecordWorkItemAsEmpty(Result.WorkItemID);
				}
				else
				{
					for(FTOPWorkResultObject WRO : Result.ResultObjects)
					{
						if(WRO.GetState() != EPDGWorkResultState::Loaded)
							bAllLoaded = false;
					}
				}
			}

			if(bAllLoaded)
			{
				this->LoadState = EPDGLoadState::Loading_Complete;
				this->SetWorkItemsDirty();
			}
		}
		else
		{
			// Cooking is not complete, so we must recheck next frame.
			this->SetWorkItemsDirty();
		}
	}
}

void UTOPNode::OnWorkItemWaiting(int32 InWorkItemID)
{
	FTOPWorkResult* const WorkItem = GetWorkResultByID(InWorkItemID);
	if (WorkItem)
	{
		// Clear the bAutoBakedSinceLastLoad flag on the work results since we are expecting a cook of the work item
		for (FTOPWorkResultObject& WRO : WorkItem->ResultObjects)
		{
			WRO.SetAutoBakedSinceLastLoad(false);
		}
	}
	WorkItemTally.RecordWorkItemAsWaiting(InWorkItemID);
}

void
UTOPNode::OnWorkItemCooked(int32 InWorkItemID)
{
	if (GetWorkItemTally().NumCookedWorkItems() == 0)
	{
		// We want to invalidate the landscape cache values in any situation where
		// all the work items are being recooked.
		InvalidateLandscapeCache();
	}
	WorkItemTally.RecordWorkItemAsCooked(InWorkItemID);
}

void
UTOPNode::OnWorkItemIgnored(int32 InWorkItemID)
{
	WorkItemTally.RecordWorkItemAsIgnored(InWorkItemID);
}

void
UTOPNode::OnWorkItemEmpty(int32 InWorkItemID)
{
	WorkItemTally.RecordWorkItemAsEmpty(InWorkItemID);
}

void
UTOPNode::OnWorkItemLoaded(int32 InWorkItemID)
{
	WorkItemTally.RecordWorkItemAsLoaded(InWorkItemID);
}

void
UTOPNode::SetVisibleInLevel(bool bInVisible)
{
	if (bShow == bInVisible)
		return;
	
	bShow = bInVisible;
	UpdateOutputVisibilityInLevel();
}


bool UTOPNode::IsPaused() const
{
	return NodeState == EPDGNodeState::Paused || LoadState == EPDGLoadState::Loading_Paused;
}

void
UTOPNode::UpdateOutputVisibilityInLevel()
{
	AActor* Actor = OutputActorOwner.GetOutputActor();
	if (IsValid(Actor))
	{
		Actor->SetHidden(!bShow);
#if WITH_EDITOR
		Actor->SetIsTemporarilyHiddenInEditor(!bShow);
#endif
	}
	for (FTOPWorkResult& WorkItem : WorkResult)
	{
		for (FTOPWorkResultObject& WRO : WorkItem.ResultObjects)
		{
			AActor* WROActor = WRO.GetOutputActorOwner().GetOutputActor();
			if (IsValid(WROActor))
			{
				WROActor->SetHidden(!bShow);
#if WITH_EDITOR
				WROActor->SetIsTemporarilyHiddenInEditor(!bShow);
#endif
			}

			// We need to manually handle child landscape's visiblity
			for (UHoudiniOutput* ResultOutput : WRO.GetResultOutputs())
			{
				if (!IsValid(ResultOutput))
					continue;

				for (auto& Pair : ResultOutput->GetOutputObjects())
				{
					FHoudiniOutputObject& OutputObject = Pair.Value;
					ALandscapeProxy* LandscapeProxy = Cast<ALandscapeProxy>(OutputObject.OutputObject);
					if (!IsValid(LandscapeProxy))
						continue;

					ALandscape* Landscape = LandscapeProxy->GetLandscapeActor();
					if (!IsValid(Landscape))
						continue;

					Landscape->SetHidden(!bShow);
#if WITH_EDITOR
					Landscape->SetIsTemporarilyHiddenInEditor(!bShow);
#endif
				}
			}
		}
	}	
}

void
UTOPNode::SetNotLoadedWorkResultsToLoad(bool bInAlsoSetDeletedToLoad)
{
	for(FTOPWorkResult& WorkItem : WorkResult)
	{
		if(WorkItem.ResultObjects.IsEmpty())
		{
			this->OnWorkItemIgnored(WorkItem.WorkItemID);
		}
		else
		{
			for(FTOPWorkResultObject& WRO : WorkItem.ResultObjects)
			{
				WRO.SetState(EPDGWorkResultState::ToLoad);
				WRO.SetAutoBakedSinceLastLoad(false);
			}
		}
	}

	this->LoadState = EPDGLoadState::Loading;
}


void
UTOPNode::SetNotLoadedWorkResultsToIgnore()
{
	for(FTOPWorkResult& WorkItem : WorkResult)
	{
		for(FTOPWorkResultObject& WRO : WorkItem.ResultObjects)
		{
			WRO.SetState(EPDGWorkResultState::NotLoaded);
			this->OnWorkItemIgnored(WorkItem.WorkItemID);
		}
	}
}

void
UTOPNode::SetLoadedWorkResultsToDelete()
{
	this->LoadState = EPDGLoadState::Unloaded;
	this->SetWorkItemsDirty();
	for (FTOPWorkResult& WorkItem : WorkResult)
	{
		if (!this->bAutoLoad)
		{
			WorkItemTally.RecordWorkItemAsCooked(WorkItem.WorkItemID);
		}
		else
		if(WorkItem.ResultObjects.IsEmpty())
		{
			WorkItemTally.RecordWorkItemAsCooked(WorkItem.WorkItemID);
		}
		else
		{
			for(FTOPWorkResultObject& WRO : WorkItem.ResultObjects)
			{
				if(WRO.GetState() == EPDGWorkResultState::Loaded)
				{
					WRO.SetState(EPDGWorkResultState::ToDelete);
				}
			}
		}
    }

}

FGuid
UTOPNode::GetHoudiniCookableGuid() const
{
	UHoudiniPDGAssetLink const* const AssetLink = GetOuterAssetLink();
	if (!IsValid(AssetLink))
		return FGuid();
	
	return AssetLink->GetOuterCookableGuid();
}

void
UTOPNode::DeleteWorkResultObjectOutputs(const int32 InWorkResultArrayIndex, const int32 InWorkResultObjectArrayIndex, const bool bInDeleteOutputActors)
{
	if (!WorkResult.IsValidIndex(InWorkResultArrayIndex))
		return;
	
	FTOPWorkResult& WorkItem = WorkResult[InWorkResultArrayIndex];
	if (!WorkItem.ResultObjects.IsValidIndex(InWorkResultObjectArrayIndex))
		return;
	
	FTOPWorkResultObject& WRO = WorkItem.ResultObjects[InWorkResultObjectArrayIndex];
	// Delete and clean up that WRObj
	WRO.DestroyResultOutputs(GetHoudiniCookableGuid());
	if (bInDeleteOutputActors)
		WRO.GetOutputActorOwner().DestroyOutputActor();
	WRO.SetState(EPDGWorkResultState::Deleted);

	// Ensure that the outer level (or actor in the case of OFPA) is marked as dirty so that references to the
	// output actors / objects are saved
	MarkPackageDirty();
}

void
UTOPNode::DeleteWorkItemOutputs(const int32 InWorkResultArrayIndex, const bool bInDeleteOutputActors)
{
	if (!WorkResult.IsValidIndex(InWorkResultArrayIndex))
		return;
	
	const FTOPWorkResult& WorkItem = WorkResult[InWorkResultArrayIndex];
	const int32 NumResultObjects = WorkItem.ResultObjects.Num();
	for (int32 ResultObjectIndex = 0; ResultObjectIndex < NumResultObjects; ++ResultObjectIndex)
	{
		DeleteWorkResultObjectOutputs(InWorkResultArrayIndex, ResultObjectIndex, bInDeleteOutputActors);
	}
}

void
UTOPNode::DeleteAllWorkResultObjectOutputs(const bool bInDeleteOutputActors)
{
	const int32 NumWorkItems = WorkResult.Num();
	for (int32 WorkItemIndex = 0; WorkItemIndex < NumWorkItems; ++WorkItemIndex)
	{
		DeleteWorkItemOutputs(WorkItemIndex, bInDeleteOutputActors);
	}
	bCachedHaveLoadedWorkResults = false;
}

FString
UTOPNode::GetBakedWorkResultObjectOutputsKey(int32 InWorkResultArrayIndex, int32 InWorkResultObjectArrayIndex)
{
	return FString::Printf(TEXT("%d_%d"), InWorkResultArrayIndex, InWorkResultObjectArrayIndex);
}

FString
UTOPNode::GetBakedWorkResultObjectOutputsKey(const FTOPWorkResult& InWorkResult, int32 InWorkResultObjectArrayIndex) const
{
	if (InWorkResult.WorkItemID == INDEX_NONE)
		return FString();

	const int32 WorkResultArrayIndex = ArrayIndexOfWorkResultByID(InWorkResult.WorkItemID);
	if (WorkResultArrayIndex == INDEX_NONE)
		return FString();
	
	return GetBakedWorkResultObjectOutputsKey(WorkResultArrayIndex, InWorkResultObjectArrayIndex);
}

bool
UTOPNode::GetBakedWorkResultObjectOutputsKey(int32 InWorkResultArrayIndex, int32 InWorkResultObjectArrayIndex, FString& OutKey) const
{
	// Check that indices are valid
	if (!WorkResult.IsValidIndex(InWorkResultArrayIndex))
		return false;
	const FTOPWorkResult& WorkResultEntry = WorkResult[InWorkResultArrayIndex];
	if (!WorkResultEntry.ResultObjects.IsValidIndex(InWorkResultObjectArrayIndex))
		return false;

	OutKey = GetBakedWorkResultObjectOutputsKey(InWorkResultArrayIndex, InWorkResultObjectArrayIndex);

	return true;
}

bool
UTOPNode::GetBakedWorkResultObjectOutputs(int32 InWorkResultArrayIndex, int32 InWorkResultObjectArrayIndex, FHoudiniPDGWorkResultObjectBakedOutput*& OutBakedOutput)
{
	FString Key;
	if (!GetBakedWorkResultObjectOutputsKey(InWorkResultArrayIndex, InWorkResultObjectArrayIndex, Key))
		return false;
	OutBakedOutput = BakedWorkResultObjectOutputs.Find(Key);
	if (!OutBakedOutput)
		return false;

	return true;
}

bool
UTOPNode::GetBakedWorkResultObjectOutputs(int32 InWorkResultArrayIndex, int32 InWorkResultObjectArrayIndex, FHoudiniPDGWorkResultObjectBakedOutput const*& OutBakedOutput) const
{
	FString Key;
	if (!GetBakedWorkResultObjectOutputsKey(InWorkResultArrayIndex, InWorkResultObjectArrayIndex, Key))
		return false;
	OutBakedOutput = BakedWorkResultObjectOutputs.Find(Key);
	if (!OutBakedOutput)
		return false;

	return true;
}

int32
UTOPNode::ArrayIndexOfWorkResultByID(const int32& InWorkItemID) const
{
	const int32 NumEntries = WorkResult.Num();
	for (int32 Index = 0; Index < NumEntries; ++Index)
	{
		const FTOPWorkResult& CurResult = WorkResult[Index];
		if (CurResult.WorkItemID == InWorkItemID)
		{
			return Index;
		}
	}

	return INDEX_NONE;
}

FTOPWorkResult*
UTOPNode::GetWorkResultByID(const int32& InWorkItemID)
{
	const int32 ArrayIndex = ArrayIndexOfWorkResultByID(InWorkItemID);
	if (!WorkResult.IsValidIndex(ArrayIndex))
		return nullptr;

	return &WorkResult[ArrayIndex];
}

int32
UTOPNode::ArrayIndexOfFirstInvalidWorkResult() const
{
	const int32 NumEntries = WorkResult.Num();
	for (int32 Index = 0; Index < NumEntries; ++Index)
	{
		const FTOPWorkResult& CurResult = WorkResult[Index];
		if (CurResult.WorkItemID == INDEX_NONE)
		{
			return Index;
		}
	}

	return INDEX_NONE;
}

FTOPWorkResult*
UTOPNode::GetWorkResultByArrayIndex(const int32& InArrayIndex)
{
	if (!WorkResult.IsValidIndex(InArrayIndex))
		return nullptr;
	return &WorkResult[InArrayIndex];
}

bool
UTOPNode::IsParentTOPNetwork(UTOPNetwork const * const InNetwork) const
{
	if (!IsValid(InNetwork))
	{
		return false;
	}

	return ParentName == FString::Printf(TEXT("%s_%s"), *InNetwork->ParentName, *InNetwork->NodeName);
}

bool
UTOPNode::CanStillBeAutoBaked(const bool bInAutoBakeWithFailedWorkItems) const
{
	// Only nodes that have results auto-loaded are auto-baked
	if (!bAutoLoad)
		return false;

	// Nodes with failures are not auto-baked depending on the value of bAutoBakeWithFailedWorkItems
	if (!bInAutoBakeWithFailedWorkItems && AnyWorkItemsFailed())
		return false;

	// All work items are not yet complete, so node cannot yet be baked
	if (!AreAllWorkItemsComplete())
		return true;

	// Work items that are currently loaded or has not tagged has auto baked since last load can still be baked
	for (const FTOPWorkResult& WorkResultEntry : WorkResult)
	{
		for (const FTOPWorkResultObject& WRO : WorkResultEntry.ResultObjects)
		{
			switch (WRO.GetState())
			{
				case EPDGWorkResultState::NotLoaded:
				case EPDGWorkResultState::ToLoad:
				case EPDGWorkResultState::Loading:
					return true;
				case EPDGWorkResultState::Loaded:
					if (!WRO.AutoBakedSinceLastLoad())
						return true;
					break;
				case EPDGWorkResultState::ToDelete:
				case EPDGWorkResultState::Deleting:
				case EPDGWorkResultState::Deleted:
				case EPDGWorkResultState::None:
					break;
			}
		}
	}

	return false;
}

#if WITH_EDITOR
void
UTOPNode::PostEditChangeChainProperty(FPropertyChangedChainEvent& InPropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(InPropertyChangedEvent);

	const FName PropertyName = InPropertyChangedEvent.GetPropertyName();
	if (PropertyName == GET_MEMBER_NAME_CHECKED(UTOPNode, bShow))
	{
		UpdateOutputVisibilityInLevel();
	}
}
#endif

#if WITH_EDITOR
void
UTOPNode::PostTransacted(const FTransactionObjectEvent& TransactionEvent)
{
	Super::PostTransacted(TransactionEvent);

	if (TransactionEvent.GetEventType() != ETransactionObjectEventType::UndoRedo)
		return;

	bool bUpdateVisibility = false;
	for (const FName& PropName : TransactionEvent.GetChangedProperties())
	{
		if (PropName == GET_MEMBER_NAME_CHECKED(UTOPNode, bShow))
		{
			bUpdateVisibility = true;
		}
	}

	if (bUpdateVisibility)
		UpdateOutputVisibilityInLevel();
}
#endif

void
UTOPNode::OnDirtyNode()
{
	InvalidateLandscapeCache();
	bHasReceivedCookCompleteEvent = false;
}

void
UTOPNode::InvalidateLandscapeCache()
{
	ClearedLayers.Empty();
}

UTOPNetwork::UTOPNetwork()
{
	NodeId = -1;
	NodeName = FString();

	AllTOPNodes.SetNum(0);
	SelectedTOPIndex = -1;

	ParentName = FString();

	bShowResults = false;
	bAutoLoadResults = true;

	NetworkState = EPDGNodeState::None;
}

bool
UTOPNetwork::operator==(const UTOPNetwork& Other) const
{
	if (!NodeName.Equals(Other.NodeName))
		return false;

	if (!ParentName.Equals(Other.ParentName))
		return false;

	return true;
}

void
UTOPNetwork::SetLoadedWorkResultsToDelete()
{
	for (UTOPNode* Node : AllTOPNodes)
	{
		if (!IsValid(Node))
			continue;
		
		Node->SetLoadedWorkResultsToDelete();
	}

	this->LoadState = EPDGLoadState::Unloaded;
}

void
UTOPNetwork::DeleteAllWorkResultObjectOutputs()
{
	for (UTOPNode* Node : AllTOPNodes)
	{
		if (!IsValid(Node))
			continue;
		
		Node->DeleteAllWorkResultObjectOutputs();
	}
}

bool
UTOPNetwork::AnyWorkItemsPending() const
{
	for (const UTOPNode* const TOPNode : AllTOPNodes)
	{
		if (!IsValid(TOPNode))
			continue;

		if (TOPNode->AnyWorkItemsPending())
			return true;
	}

	return false;
}

bool
UTOPNetwork::AnyWorkItemsFailed() const
{
	for (const UTOPNode* const TOPNode : AllTOPNodes)
	{
		if (!IsValid(TOPNode))
			continue;

		if (TOPNode->AnyWorkItemsFailed())
			return true;
	}

	return false;
}

bool
UTOPNetwork::CanStillBeAutoBaked(const bool bInAutoBakeWithFailedWorkItems) const
{
	// As long as there are still pending work items in the network, something could still be auto baked
	if (AnyWorkItemsPending())
		return true;

	for (const UTOPNode* const TOPNode : AllTOPNodes)
	{
		if (TOPNode->CanStillBeAutoBaked(bInAutoBakeWithFailedWorkItems))
			return true;
	}

	return false;
}

int UTOPNetwork::GetTotalOutputWorkItems()
{
	int Total = 0;
	for(UTOPNode* CurrentTOPNode : this->AllTOPNodes)
	{
		if(!IsValid(CurrentTOPNode))
			continue;

		if(CurrentTOPNode->bAutoLoad)
			Total++;

	}
	return Total;
}

int UTOPNetwork::GetCompletedOutputWorkItems()
{
	int Total = 0;
	for(UTOPNode* CurrentTOPNode : this->AllTOPNodes)
	{
		if(!IsValid(CurrentTOPNode))
			continue;

		if(!CurrentTOPNode->bAutoLoad)
			continue;

		const int32 NumWorkResults = CurrentTOPNode->WorkResult.Num();
		for(int32 WorkResultIndex = 0; WorkResultIndex < NumWorkResults; ++WorkResultIndex)
		{
			FTOPWorkResult& CurrentWorkResult = CurrentTOPNode->WorkResult[WorkResultIndex];
			int32 NumResultObjects = CurrentWorkResult.ResultObjects.Num();

			for(int32 ResultIndex = 0; ResultIndex < NumResultObjects; ++ResultIndex)
			{
				if(CurrentWorkResult.ResultObjects[ResultIndex].GetState() == EPDGWorkResultState::Loaded)
				{
					Total++;
				}

			}
		}
	}
	return Total;
}

bool
UTOPNetwork::EvaluateWorkItems()
{
	bool bAllLoaded = true;
	bool bFailed = false;
	for (auto Node : AllTOPNodes)
	{
		Node->EvaluateWorkItems();
		if(Node->LoadState != EPDGLoadState::Loading_Complete && Node->LoadState != EPDGLoadState::IgnoredForLoad)
			bAllLoaded = false;

		if(Node->LoadState == EPDGLoadState::Loading_Failed)
			bFailed = true;


	}

	if(bFailed)
	{
		this->LoadState = EPDGLoadState::Loading_Failed;

		if(OnPostCookDelegate.IsBound())
			OnPostCookDelegate.Broadcast(this, AnyWorkItemsFailed());
	}
	else if(this->LoadState == EPDGLoadState::Loading && bAllLoaded)
	{
		this->LoadState = EPDGLoadState::Loading_Complete;

		if(OnPostCookDelegate.IsBound())
			OnPostCookDelegate.Broadcast(this, AnyWorkItemsFailed());
	}

	return true;
}

void
UTOPNetwork::SetNotLoadedWorkResultsToLoad(bool bInAlsoSetDeletedToLoad, const FString &InFilter)
{
	for (auto TopNode : AllTOPNodes)
	{
		if(IsValid(TopNode) && TopNode->NodeName.StartsWith(InFilter))
			TopNode->SetNotLoadedWorkResultsToLoad(bInAlsoSetDeletedToLoad);
		else
			TopNode->SetNotLoadedWorkResultsToIgnore();

		TopNode->LoadState = EPDGLoadState::Loading;
		TopNode->SetWorkItemsDirty();
	}

	this->LoadState = EPDGLoadState::Loading;
}

bool
UTOPNetwork::IsPaused()
{
	return NetworkState == EPDGNodeState::Paused || LoadState == EPDGLoadState::Loading_Paused;
}

void
UTOPNetwork::HandleOnPDGEventCookCompleteReceivedByChildNode(UHoudiniPDGAssetLink* const InAssetLink, UTOPNode* const InTOPNode)
{
	if (!IsValid(InAssetLink))
		return;

	// Ensure that the work item tally is up to date, since we rely on it below
	InAssetLink->UpdateWorkItemTally();

	// Check if all nodes have received the HAPI_PDG_EVENT_COOK_COMPLETE event, if so, broadcast the OnPostCook handler.
	for (const UTOPNode* const TOPNode : AllTOPNodes)
	{
		if (!IsValid(TOPNode))
			continue;

		// For nodes with child nodes, only the child nodes receive HAPI_PDG_EVENT_COOK_COMPLETE
		if (TOPNode->bHasChildNodes)
			continue;

		// If the node has not received cook complete, and it has work items, then the network is not done cooking
		// (Nodes that are bypassed in the network, or that don't have any work items generated, don't receive
		//  HAPI_PDG_EVENT_COOK_COMPLETE)
		if (!TOPNode->HasReceivedCookCompleteEvent() && TOPNode->WorkResult.Num() > 0)
			return;
	}

	InAssetLink->HandleOnTOPNetworkCookComplete(this);

	this->NetworkState = EPDGNodeState::Cook_Complete;

}

void
UHoudiniPDGAssetLink::SelectTOPNetwork(const int32& AtIndex)
{
	if (!AllTOPNetworks.IsValidIndex(AtIndex))
		return;

	SelectedTOPNetworkIndex = AtIndex;
}

UWorld*
UHoudiniPDGAssetLink::GetOutputWorld()
{
	if(IsValid(OutputWorld))
		return OutputWorld;
	else
		return GetWorld();
}

void
UHoudiniPDGAssetLink::SetOutputWorld(UWorld * World)
{
	OutputWorld = World;
}

void
UHoudiniPDGAssetLink::SelectTOPNode(UTOPNetwork* InTOPNetwork, const int32& AtIndex)
{
	if (!IsValid(InTOPNetwork))
		return;
	
	if (!InTOPNetwork->AllTOPNodes.IsValidIndex(AtIndex))
		return;

	InTOPNetwork->SelectedTOPIndex = AtIndex;
}


UTOPNetwork*
UHoudiniPDGAssetLink::GetSelectedTOPNetwork()
{
	return GetTOPNetwork(SelectedTOPNetworkIndex);
}

const UTOPNetwork*
UHoudiniPDGAssetLink::GetSelectedTOPNetwork() const
{
	return GetTOPNetwork(SelectedTOPNetworkIndex);
}

UTOPNode*
UHoudiniPDGAssetLink::GetSelectedTOPNode()
{
	UTOPNetwork* const SelectedTOPNetwork = GetSelectedTOPNetwork();
	if (!IsValid(SelectedTOPNetwork))
		return nullptr;

	if (!SelectedTOPNetwork->AllTOPNodes.IsValidIndex(SelectedTOPNetwork->SelectedTOPIndex))
		return nullptr;

	UTOPNode* const SelectedTOPNode = SelectedTOPNetwork->AllTOPNodes[SelectedTOPNetwork->SelectedTOPIndex];
	if (!IsValid(SelectedTOPNode))
		return nullptr;

	return SelectedTOPNode;
}

const UTOPNode*
UHoudiniPDGAssetLink::GetSelectedTOPNode() const
{
	UTOPNetwork const* const SelectedTOPNetwork = GetSelectedTOPNetwork();
	if (!IsValid(SelectedTOPNetwork))
		return nullptr;

	if (!SelectedTOPNetwork->AllTOPNodes.IsValidIndex(SelectedTOPNetwork->SelectedTOPIndex))
		return nullptr;

	UTOPNode const* const SelectedTOPNode = SelectedTOPNetwork->AllTOPNodes[SelectedTOPNetwork->SelectedTOPIndex];
	if (!IsValid(SelectedTOPNode))
		return nullptr;

	return SelectedTOPNode;
}

FString
UHoudiniPDGAssetLink::GetSelectedTOPNodeName()
{
	FString NodeName = FString();

	const UTOPNode* const SelectedTOPNode = GetSelectedTOPNode();
	if (IsValid(SelectedTOPNode))
		NodeName = SelectedTOPNode->NodeName;

	return NodeName;
}

FString
UHoudiniPDGAssetLink::GetSelectedTOPNetworkName()
{
	FString NetworkName = FString();

	const UTOPNetwork* const SelectedTOPNetwork = GetSelectedTOPNetwork();
	if (IsValid(SelectedTOPNetwork))
		NetworkName = SelectedTOPNetwork->NodeName;

	return NetworkName;
}

UTOPNetwork* 
UHoudiniPDGAssetLink::GetTOPNetwork(const int32& AtIndex)
{
	if(AllTOPNetworks.IsValidIndex(AtIndex))
	{
		return AllTOPNetworks[AtIndex];
	}

	return nullptr;
}

const UTOPNetwork* 
UHoudiniPDGAssetLink::GetTOPNetwork(const int32& AtIndex) const
{
	if(AllTOPNetworks.IsValidIndex(AtIndex))
	{
		return AllTOPNetworks[AtIndex];
	}

	return nullptr;
}

UTOPNetwork*
UHoudiniPDGAssetLink::GetTOPNetworkForNode(const UTOPNode* InNode) const
{
	if (!IsValid(InNode))
		return nullptr;

	// TODO: add a parent node pointer (or perhaps have the parent network as the outer / in the outer chain of the node?)
	// to UTOPNode to prevent having to do these parent name and array Contains searches
	const int32 NumTOPNet = AllTOPNetworks.Num();
	for (int32 Index = 0; Index < NumTOPNet; ++Index)
	{
		UTOPNetwork* const TOPNet = AllTOPNetworks[Index];
		if (!IsValid(TOPNet))
			continue;

		if (InNode->ParentName != TOPNet->ParentName + TEXT("_") + TOPNet->NodeName)
			continue;

		if (TOPNet->AllTOPNodes.Contains(InNode))
			return TOPNet;
	}

	return nullptr;
}

UTOPNetwork*
UHoudiniPDGAssetLink::GetTOPNetworkByNodePath(const FString& InNodePath, const TArray<UTOPNetwork*>& InTOPNetworks, int32& OutIndex)
{
	OutIndex = INDEX_NONE;
	int32 Index = -1;
	for (UTOPNetwork* CurrentTOPNet : InTOPNetworks)
	{
		Index += 1;

		if (!IsValid(CurrentTOPNet))
			continue;
		
		if (CurrentTOPNet->NodePath.Equals(InNodePath))
		{
			OutIndex = Index;
			return CurrentTOPNet;
		}
	}

	return nullptr;
}

UTOPNode*
UHoudiniPDGAssetLink::GetParentTOPNode(const UTOPNode* InNode)
{
	if (!IsValid(InNode))
		return nullptr;
	
	FString NodePath = InNode->NodePath;
	FString ParentPath;

	if (NodePath.EndsWith("/"))
		NodePath.LeftChopInline(1);

	if (NodePath.Split("/", &ParentPath, nullptr, ESearchCase::IgnoreCase, ESearchDir::FromEnd) && !ParentPath.IsEmpty())
	{
		for (UTOPNetwork* TOPNet : AllTOPNetworks)
		{
			if (!IsValid(TOPNet))
				continue;
			
			for (UTOPNode* TOPNode : TOPNet->AllTOPNodes)
			{
				if (!IsValid(TOPNode))
					continue;
				
				if (TOPNode->NodePath == ParentPath && InNode->NodeId != TOPNode->NodeId)
				{
					return TOPNode;
				}
			}
		}
	}

	return nullptr;
}

UTOPNode*
UHoudiniPDGAssetLink::GetTOPNodeByNodePath(const FString& InNodePath, const TArray<UTOPNode*>& InTOPNodes, int32& OutIndex)
{
	OutIndex = INDEX_NONE;
	int32 Index = -1;
	for (UTOPNode* CurrentTOPNode : InTOPNodes)
	{
		Index += 1;
		
		if (!IsValid(CurrentTOPNode))
			continue;
		
		if (CurrentTOPNode->NodePath.Equals(InNodePath))
		{
			OutIndex = Index;
			return CurrentTOPNode;
		}
	}

	return nullptr;
}

void
UHoudiniPDGAssetLink::ClearAllTOPData()
{
	// Clears all TOP data
	for(UTOPNetwork* CurrentNetwork : AllTOPNetworks)
	{
		if (!IsValid(CurrentNetwork))
			continue;
		
		for(UTOPNode* CurrentTOPNode : CurrentNetwork->AllTOPNodes)
		{
			if (!IsValid(CurrentTOPNode))
				continue;
			
			ClearTOPNodeWorkItemResults(CurrentTOPNode);
		}
	}

	AllTOPNetworks.Empty();
}

void 
UHoudiniPDGAssetLink::ClearTOPNetworkWorkItemResults(UTOPNetwork* TOPNetwork)
{
	if (!IsValid(TOPNetwork))
		return;
	
	for(UTOPNode* CurrentTOPNode : TOPNetwork->AllTOPNodes)
	{
		if (!IsValid(CurrentTOPNode))
			continue;
		
		ClearTOPNodeWorkItemResults(CurrentTOPNode);

		CurrentTOPNode->LoadState = EPDGLoadState::None;
		CurrentTOPNode->SetWorkItemsDirty();
	}
}

void
UHoudiniPDGAssetLink::ClearTOPNodeWorkItemResults(UTOPNode* TOPNode)
{
	if (!IsValid(TOPNode))
		return;

	TOPNode->OnDirtyNode();

	const FGuid CookableGuid(TOPNode->GetHoudiniCookableGuid());
	for(FTOPWorkResult& CurrentWorkResult : TOPNode->WorkResult)
	{
		CurrentWorkResult.ClearAndDestroyResultObjects(CookableGuid);
	}
	TOPNode->WorkResult.Empty();

	FOutputActorOwner& OutputActorOwner = TOPNode->GetOutputActorOwner();
	AActor* OutputActor = OutputActorOwner.GetOutputActor();
	if (IsValid(OutputActor))
	{
		// Destroy any attached actors (which we'll assume that any attachments left
		// are untracked actors associated with the TOPNode)
		TArray<AActor*> AttachedActors;
		OutputActor->GetAttachedActors(AttachedActors);
		for (AActor* Actor : AttachedActors)
		{
			if (!IsValid(Actor))
				continue;
			Actor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
			Actor->Destroy();
		}
	}

	if (IsValid(TOPNode->WorkResultParent))
	{

		// TODO: Destroy the Parent Object
		// DestroyImmediate(topNode._workResultParentGO);
	}

	OutputActorOwner.DestroyOutputActor();

	// Ensure that the outer level (or actor in the case of OFPA) is marked as dirty so that changes to the
	// output actors / objects are saved
	TOPNode->MarkPackageDirty();
}


void
UHoudiniPDGAssetLink::ClearWorkItemResultByID(const int32& InWorkItemID, UTOPNode* InTOPNode)
{
	if (!IsValid(InTOPNode))
		return;
	
	FTOPWorkResult* WorkResult = GetWorkResultByID(InWorkItemID, InTOPNode);
	if (WorkResult)
	{
		WorkResult->ClearAndDestroyResultObjects(InTOPNode->GetHoudiniCookableGuid());
		// TODO: Should we destroy the FTOPWorkResult struct entirely here?
		//TOPNode.WorkResult.RemoveByPredicate

		// Ensure that the outer level (or actor in the case of OFPA) is marked as dirty so that changes to the
		// output actors / objects are saved
		InTOPNode->MarkPackageDirty();
	}
}

void
UHoudiniPDGAssetLink::DestroyWorkItemByID(const int32& InWorkItemID, UTOPNode* InTOPNode)
{
	if (!IsValid(InTOPNode))
		return;
	
	// TODO: Update ClearWorkItemResultByID or GetWorkResultByID to return the index of the work item
	// so that we don't have to find its index again to remove it from the array
	ClearWorkItemResultByID(InWorkItemID, InTOPNode);
	// Find the index of the FTOPWorkResult for InWorkItemID in InTOPNode.WorkResult and remove it
	const int32 Index = InTOPNode->WorkResult.IndexOfByPredicate(
		[InWorkItemID](const FTOPWorkResult& InWorkItem) { return InWorkItem.WorkItemID == InWorkItemID; });
	if (Index != INDEX_NONE && Index >= 0)
		InTOPNode->WorkResult.RemoveAt(Index);
}

FTOPWorkResult*
UHoudiniPDGAssetLink::GetWorkResultByID(const int32& InWorkItemID, UTOPNode* InTOPNode)
{
	if (!IsValid(InTOPNode))
		return nullptr;
	return InTOPNode->GetWorkResultByID(InWorkItemID);
}

FDirectoryPath
UHoudiniPDGAssetLink::GetTemporaryCookFolder() const
{
	UHoudiniCookable* HC = GetOuterHoudiniCookable();
	if (HC)
		return HC->GetTemporaryCookFolder();
	
	FDirectoryPath TempPath;
	TempPath.Path = FHoudiniEngineRuntime::Get().GetDefaultTemporaryCookFolder();
	return TempPath;
}

FGuid
UHoudiniPDGAssetLink::GetOuterCookableGuid() const
{
	UHoudiniCookable* HC = GetOuterHoudiniCookable();
	if (!IsValid(HC))
		return FGuid();

	return HC->GetCookableGUID();
}

void
UHoudiniPDGAssetLink::HandleOnTOPNetworkCookComplete(UTOPNetwork* const InTOPNet)
{
	if (!IsValid(InTOPNet))
		return;

	if (OnPostTOPNetworkCookDelegate.IsBound())
	{
		OnPostTOPNetworkCookDelegate.Broadcast(this, InTOPNet, InTOPNet->AnyWorkItemsFailed());
	}
}


UTOPNode*
UHoudiniPDGAssetLink::GetTOPNode(const int32& InNodeID)
{
	UTOPNetwork* Network = nullptr;
	UTOPNode* Node = nullptr;

	if (GetTOPNodeAndNetworkByNodeId(InNodeID, Network, Node))
		return Node;

	return nullptr;
}


bool
UHoudiniPDGAssetLink::GetTOPNodeAndNetworkByNodeId(const int32& InNodeID, UTOPNetwork*& OutNetwork, UTOPNode*& OutNode)
{
	OutNetwork = nullptr;
	OutNode = nullptr;

	for (UTOPNetwork* CurrentTOPNet : AllTOPNetworks)
	{
		if (!IsValid(CurrentTOPNet))
			continue;
		
		for (UTOPNode* CurrentTOPNode : CurrentTOPNet->AllTOPNodes)
		{
			if (!IsValid(CurrentTOPNode))
				continue;
			
			if (CurrentTOPNode->NodeId == InNodeID)
			{
				OutNetwork = CurrentTOPNet;
				OutNode = CurrentTOPNode;
				return true;
			}
		}
	}

	return false;
}


void
UHoudiniPDGAssetLink::UpdateTOPNodeWithChildrenWorkItemTallyAndState(UTOPNode* InNode, UTOPNetwork* InNetwork)
{
	if (!IsValid(InNode) || !IsValid(InNetwork))
		return;
	
	if (!InNode->bHasChildNodes)
		return;

	FString PrefixPath = InNode->NodePath;
	if (!PrefixPath.EndsWith("/"))
		PrefixPath += "/";
	InNode->ZeroWorkItemTally();
	InNode->NodeState = EPDGNodeState::None;

	TMap<EPDGNodeState, int8> NodeStateOrder;
	NodeStateOrder.Add(EPDGNodeState::None, 0);
	NodeStateOrder.Add(EPDGNodeState::Cook_Complete, 1);
	NodeStateOrder.Add(EPDGNodeState::Dirtied, 2);
	NodeStateOrder.Add(EPDGNodeState::Cook_Failed, 3);
	NodeStateOrder.Add(EPDGNodeState::Dirtying, 4);
	NodeStateOrder.Add(EPDGNodeState::Cooking, 5);

	int8 CurrentState = 0;
	
	for (const UTOPNode* Node : InNetwork->AllTOPNodes)
	{
		if (!IsValid(Node))
			continue;
		
		if (Node->NodePath.StartsWith(PrefixPath) && !Node->bHasChildNodes)
		{
			InNode->AggregateTallyFromChildNode(Node);
			const int8 VisitedNodeState = NodeStateOrder.FindChecked(Node->NodeState);
			if (VisitedNodeState > CurrentState)
				CurrentState = VisitedNodeState;
		}
	}

	EPDGNodeState const* const NewState = NodeStateOrder.FindKey(CurrentState);
	if (NewState)
		InNode->NodeState = *NewState;
}

void
UHoudiniPDGAssetLink::UpdateWorkItemTally()
{
	WorkItemTally.ZeroAll();		
	for(UTOPNetwork* CurrentTOPNet : AllTOPNetworks)
	{
		if (!IsValid(CurrentTOPNet))
			continue;
		
		for(UTOPNode* CurrentTOPNode : CurrentTOPNet->AllTOPNodes)
		{
			if (!IsValid(CurrentTOPNode))
				continue;
			
			// Only add up the tallys from nodes without children (since parent's aggregate the child work items counts)
			if (CurrentTOPNode->bHasChildNodes)
			{
				UpdateTOPNodeWithChildrenWorkItemTallyAndState(CurrentTOPNode, CurrentTOPNet);
			}
			else
			{
				WorkItemTally.Add(CurrentTOPNode->GetWorkItemTally());
			}
		}
	}
}


void
UHoudiniPDGAssetLink::ResetTOPNetworkWorkItemTally(UTOPNetwork* TOPNetwork)
{
	if (!IsValid(TOPNetwork))
		return;
	
	for (UTOPNode* CurTOPNode : TOPNetwork->AllTOPNodes)
	{
		if (!IsValid(CurTOPNode))
			continue;
		
		CurTOPNode->ZeroWorkItemTally();
	}
}

FString UHoudiniPDGAssetLink::GetLoadStatus(EPDGLoadState LoadState)
{
	switch(LoadState)
	{
	case EPDGLoadState::None:
		return TEXT("Ready");
	case EPDGLoadState::Loading_Paused:
		return TEXT("Paused");
	case EPDGLoadState::Loading:
		return TEXT("Importing Remaining Work Items");
	case EPDGLoadState::LoadDisabled:
		return TEXT("Importing Disabled");
	case EPDGLoadState::Loading_Complete:
		return TEXT("Importing Complete");
	case EPDGLoadState::Unloaded:
		return TEXT("Unloaded");
	default:
		break;
	}
	return TEXT("");
}

FLinearColor UHoudiniPDGAssetLink::GetLoadStatusColor(EPDGLoadState NodeState)
{
	return FLinearColor::White;
}


FString UHoudiniPDGAssetLink::GetTOPNodeStatus(EPDGNodeState NodeState)
{
	switch(NodeState)
	{
	case EPDGNodeState::None:
		return TEXT("Ready");
	case EPDGNodeState::Cook_Failed:
		return TEXT("Cook Failed");
	case EPDGNodeState::Cook_Complete:
		return TEXT("PDG Cook Complete");
	case EPDGNodeState::Cooking:
		return TEXT("Cook In Progress");
	case EPDGNodeState::Dirtied:
		return TEXT("Dirtied");
	case EPDGNodeState::Dirtying:
		return TEXT("Dirtying");
	case EPDGNodeState::Paused:
	case EPDGNodeState::Cancelled:
		return TEXT("Cancelled");
	default:
		break;
	}
	return TEXT("");
}

FLinearColor UHoudiniPDGAssetLink::GetTOPNodeStatusColor(EPDGNodeState NodeState)
{
	switch(NodeState)
	{
	case EPDGNodeState::None:
		return FLinearColor::Green;
	case EPDGNodeState::Cook_Failed:
		return FLinearColor::Red;
	case EPDGNodeState::Cook_Complete:
		return FLinearColor::Green;
	case EPDGNodeState::Cooking:
		return FLinearColor(0.0, 1.0f, 1.0f);
	case EPDGNodeState::Dirtied:
		return FLinearColor(1.0f, 0.5f, 0.0f);
	case EPDGNodeState::Dirtying:
		return FLinearColor(0.5f, 0.5f, 0.5f);
	case EPDGNodeState::Paused:
	case EPDGNodeState::Cancelled:
		return FLinearColor(1.0f, 0.0f, 0.0f);

	default:
		break;
	}
	return FLinearColor::White;
}

FString
UHoudiniPDGAssetLink::GetTOPNodeStatus(const UTOPNode* InTOPNode)
{
	static const FString InvalidOrUnknownStatus = TEXT("");

	if(InTOPNode->AnyWorkItemsFailed())
		return GetTOPNodeStatus(EPDGNodeState::Cook_Failed);
	else
		return GetTOPNodeStatus(InTOPNode->NodeState);
}


FLinearColor
UHoudiniPDGAssetLink::GetTOPNodeStatusColor(const UTOPNode* InTOPNode)
{
	if (!IsValid(InTOPNode))
		return FLinearColor::White;

	if(InTOPNode->AnyWorkItemsFailed())
		return GetTOPNodeStatusColor(EPDGNodeState::Cook_Failed);
	else
		return GetTOPNodeStatusColor(InTOPNode->NodeState);
}

AActor*
UHoudiniPDGAssetLink::GetOwnerActor() const
{
	UObject* Outer = GetOuter();
	UActorComponent* Component = Cast<UActorComponent>(Outer);
	if (IsValid(Component))
		return Component->GetOwner();
	else
		return Cast<AActor>(Outer);
}

bool
UHoudiniPDGAssetLink::HasTemporaryOutputs() const
{
	// Loop over all networks, all nodes, all work items and check for any valid output objects
	for (const UTOPNetwork* TOPNetwork : AllTOPNetworks)
	{
		if (!IsValid(TOPNetwork))
			continue;
		
		for (const UTOPNode* TOPNode : TOPNetwork->AllTOPNodes)
		{
			if (!IsValid(TOPNode))
				continue;
			
			for (const FTOPWorkResult& WorkResult : TOPNode->WorkResult)
			{
				for (const FTOPWorkResultObject& WorkResultObject : WorkResult.ResultObjects)
				{
					// If the WorkResultObject's actor is not valid, then it no longer has temporary objects in the
					// scene
					if (!IsValid(WorkResultObject.GetOutputActorOwner().GetOutputActor()))
						continue;
					
					for (UHoudiniOutput* Output : WorkResultObject.GetResultOutputs())
					{
						if (!IsValid(Output))
							continue;

						const EHoudiniOutputType OutputType = Output->GetType();
						for (const auto& OutputObjectPair : Output->GetOutputObjects())
						{
							if ((OutputType == EHoudiniOutputType::Landscape && IsValid(OutputObjectPair.Value.OutputObject)) ||
								OutputObjectPair.Value.OutputComponents.Num() > 0)
							{
								return true;								
							}
						}
					}
				}
			}
		}
	}

	return false;
}

void
UHoudiniPDGAssetLink::UpdatePostDuplicate()
{
	// Loop over all networks, all nodes, all work items and clear output actors
	for (UTOPNetwork* TOPNetwork : AllTOPNetworks)
	{
		if (!IsValid(TOPNetwork))
			continue;
		
		for (UTOPNode* TOPNode : TOPNetwork->AllTOPNodes)
		{
			if (!IsValid(TOPNode))
				continue;
			
			for (FTOPWorkResult& WorkResult : TOPNode->WorkResult)
			{
				for (FTOPWorkResultObject& WorkResultObject : WorkResult.ResultObjects)
				{
					WorkResultObject.GetOutputActorOwner().SetOutputActor(nullptr);
					WorkResultObject.SetState(EPDGWorkResultState::None);
					WorkResultObject.SetResultOutputs(TArray<UHoudiniOutput*>());
				}
			}
			TOPNode->GetOutputActorOwner().SetOutputActor(nullptr);
			TOPNode->bCachedHaveNotLoadedWorkResults = false;
			TOPNode->bCachedHaveLoadedWorkResults = false;
		}
	}
}

UHoudiniCookable* 
UHoudiniPDGAssetLink::GetOuterHoudiniCookable() const
{
	UHoudiniCookable* FoundHC = Cast<UHoudiniCookable>(GetTypedOuter<UHoudiniCookable>());
	if (FoundHC)
		return FoundHC;

	return nullptr;
}

void
UHoudiniPDGAssetLink::UpdateTOPNodeAutoloadAndVisibility()
{
	for (UTOPNetwork* TOPNetwork : AllTOPNetworks)
	{
		if (!IsValid(TOPNetwork))
			continue;
		
		for (UTOPNode* TOPNode : TOPNetwork->AllTOPNodes)
		{
			if (!IsValid(TOPNode))
				continue;
			
			if (TOPNode->bAutoLoad)
			{
				// // Set work results that are cooked but in NotImported state to ToImport
				// TOPNode.SetNotLoadedWorkResultsToLoad();
			}
			
			TOPNode->UpdateOutputVisibilityInLevel();
		}
	}
}

void
UHoudiniPDGAssetLink::FilterTOPNodesAndOutputs()
{
	for (UTOPNetwork* TOPNetwork : AllTOPNetworks)
	{
		if (!IsValid(TOPNetwork))
			continue;
		
		for (UTOPNode* TOPNode : TOPNetwork->AllTOPNodes)
		{
			if (!IsValid(TOPNode))
				continue;
			
			// TOP Node visibility filter via TOPNodeFilter
			if (bUseTOPNodeFilter)
			{
				TOPNode->bHidden = !TOPNodeFilter.IsEmpty() && !TOPNode->NodeName.StartsWith(TOPNodeFilter);
			}
			else
			{
				TOPNode->bHidden = false;
			}

			// Auto load results filter via TOPNodeOutputFilter
			if (bUseTOPOutputFilter)
			{
				const bool bNewAutoLoad = TOPOutputFilter.IsEmpty() || TOPNode->NodeName.StartsWith(TOPOutputFilter);
				if (bNewAutoLoad != TOPNode->bAutoLoad)
				{
					if (bNewAutoLoad)
					{
						// Set work results that are cooked but in NotImported state to ToImport
						TOPNode->bAutoLoad = true;
						// TOPNode->SetNotLoadedWorkResultsToLoad();
						TOPNode->SetVisibleInLevel(true);
					}
					else
					{
						TOPNode->bAutoLoad = false;
						TOPNode->SetVisibleInLevel(false);
					}
					TOPNode->UpdateOutputVisibilityInLevel();
				}
			}
		}
	}
}

#if WITH_EDITORONLY_DATA
bool
UHoudiniPDGAssetLink::AnyRemainingAutoBakeNodes() const
{
	if (!bBakeAfterAllWorkResultObjectsLoaded)
		return false;

	switch (PDGBakeSelectionOption)
	{
		case EPDGBakeSelectionOption::All:
		{
			for (const UTOPNetwork* const TOPNet : AllTOPNetworks)
			{
				if (!IsValid(TOPNet))
					continue;

				if (TOPNet->CanStillBeAutoBaked(bAutoBakeNodesWithFailedWorkItems))
				{
					return true;
				}
			}
			break;
		}
		case EPDGBakeSelectionOption::SelectedNetwork:
		{
			const UTOPNetwork* const TOPNet = GetSelectedTOPNetwork();
			if (IsValid(TOPNet) && TOPNet->CanStillBeAutoBaked(bAutoBakeNodesWithFailedWorkItems))
			{
				return true;
			}
		}
		case EPDGBakeSelectionOption::SelectedNode:
		{
			UTOPNode const* const TOPNode = GetSelectedTOPNode();
			if (IsValid(TOPNode))
			{
				const UTOPNetwork* const TOPNet = GetTOPNetworkForNode(TOPNode);
				// If the network still has pending items, it could add dynamic items to TOPNode (we don't currently
				// have a way to check for dynamic work items explicitly.)
				if (IsValid(TOPNet) && TOPNet->AnyWorkItemsPending())
					return true;
				if (TOPNode->CanStillBeAutoBaked(bAutoBakeNodesWithFailedWorkItems))
					return true;
			}
		}
		default:
			return false;
	}

	return false;
}
#endif

void
UHoudiniPDGAssetLink::OnNodeAutoBaked(UTOPNode* InTOPNode, const bool bInSuccess)
{
	if (!IsValid(InTOPNode))
		return;

	NumAttemptedNodeAutoBakes++;
	if (bInSuccess)
		NumSuccessfulNodeAutoBakes++; 
}

void
UHoudiniPDGAssetLink::HandleOnPostBake(const bool bInSuccess)
{
	if (OnPostBakeDelegate.IsBound())
		OnPostBakeDelegate.Broadcast(this, bInSuccess);
	NumAttemptedNodeAutoBakes = 0;
	NumSuccessfulNodeAutoBakes = 0; 
}

bool
UHoudiniPDGAssetLink::BroadcastPostAutoBakeDelegateIfRequired()
{
#if WITH_EDITOR
	if (!bBakeAfterAllWorkResultObjectsLoaded || NumAttemptedNodeAutoBakes <= 0 || AnyRemainingAutoBakeNodes())
		return false;
	
	HandleOnPostBake(NumSuccessfulNodeAutoBakes > 0);
	
	return true;
#else
	return false;
#endif
}

#if WITH_EDITORONLY_DATA
void
UHoudiniPDGAssetLink::PostEditChangeChainProperty(FPropertyChangedChainEvent& InPropertyChangedChainEvent)
{
	Super::PostEditChangeChainProperty(InPropertyChangedChainEvent);

	const FName PropertyName = InPropertyChangedChainEvent.GetPropertyName();
	if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, bUseTOPNodeFilter) ||
		PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, TOPNodeFilter) ||
		PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, bUseTOPOutputFilter) ||
		PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, TOPOutputFilter))
	{
		// Refilter TOP nodes
		FilterTOPNodesAndOutputs();
		bNeedsUIRefresh = true;
	}
	else if (PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, SelectedTOPNetworkIndex) ||
			 PropertyName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, bBakeMenuExpanded))
	{
		bNeedsUIRefresh = true;
	}
}

#endif

#if WITH_EDITORONLY_DATA
void
UHoudiniPDGAssetLink::PostTransacted(const FTransactionObjectEvent& TransactionEvent)
{
	Super::PostTransacted(TransactionEvent);
	
	if (TransactionEvent.GetEventType() != ETransactionObjectEventType::UndoRedo)
		return;

	bool bDoFilterTOPNodesAndOutputs = false;
	for (const FName& PropName : TransactionEvent.GetChangedProperties())
	{
		if (PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, bUseTOPNodeFilter) ||
			PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, TOPNodeFilter) ||
			PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, bUseTOPOutputFilter) ||
			PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, TOPOutputFilter))
		{
			bDoFilterTOPNodesAndOutputs = true;
			bNeedsUIRefresh = true;
		}
		else if (PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, SelectedTOPNetworkIndex) ||
				 PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, HoudiniEngineBakeOption) ||
				 PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, PDGBakeSelectionOption) ||
				 PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, PDGBakePackageReplaceMode) ||
				 PropName == GET_MEMBER_NAME_STRING_CHECKED(UHoudiniPDGAssetLink, bBakeMenuExpanded))
		{
			bNeedsUIRefresh = true;
		}
	}

	if (bDoFilterTOPNodesAndOutputs)
		FilterTOPNodesAndOutputs();
}
#endif

void
FTOPWorkResultObject::DestroyResultOutputs(const FGuid& InHoudiniComponentGuid)
{
	TSet<UObject*> OutputObjectsToDelete;

	const FString ComponentGuidString = InHoudiniComponentGuid.IsValid() ? InHoudiniComponentGuid.ToString() : FString();

	// Delete output components and gather output objects for deletion
	bool bDidDestroyObjects = false;
	bool bDidModifyFoliage = false;

	AActor* const OutputActor = OutputActorOwner.GetOutputActor();	
	for (UHoudiniOutput* CurOutput : ResultOutputs)
	{
		if (!IsValid(CurOutput))
			continue;
		FHoudiniLandscapeRuntimeUtils::DeleteLandscapeSplineCookedData(CurOutput);
		FHoudiniLandscapeRuntimeUtils::DeleteLandscapeCookedData(CurOutput);

		for (auto& Pair : CurOutput->GetOutputObjects())
		{
			FHoudiniOutputObjectIdentifier& Identifier = Pair.Key;
			FHoudiniOutputObject& OutputObject = Pair.Value;
			for(int Index = 0; Index < OutputObject.OutputComponents.Num(); Index++)
			{
				UObject* Component = OutputObject.OutputComponents[Index];
				if (!IsValid(Component))
					continue;

				// Instancer components require some special handling around foliage
				// TODO: move/refactor so that we can use the InstanceTranslator's helper functions (RemoveAndDestroyComponent and CleanupFoliageInstances)
				bool bDestroyComponent = true;
				if (Component->IsA<UHierarchicalInstancedStaticMeshComponent>())
				{
					UHierarchicalInstancedStaticMeshComponent* HISMC = Cast<UHierarchicalInstancedStaticMeshComponent>(Component);
					if (HISMC->GetOwner() && HISMC->GetOwner()->IsA<AInstancedFoliageActor>())
					{
						// Make sure foliage our foliage instances have been removed
						USceneComponent* ParentComponent = nullptr;
						if (IsValid(OutputActor))
						{
							ParentComponent = Cast<USceneComponent>(OutputActor->GetRootComponent());
						}
						else
						{
							ParentComponent = Cast<USceneComponent>(HISMC->GetOuter());
							if (!ParentComponent)
							{
								UHoudiniCookable* OuterCookable = Cast<UHoudiniCookable>(HISMC->GetOuter());
								ParentComponent = OuterCookable ? OuterCookable->GetComponent() : nullptr;
							}
						}
							
						if (IsValid(ParentComponent))
						{
							UStaticMesh* FoliageSM = HISMC->GetStaticMesh();
							if (!IsValid(FoliageSM))
								return;

							// If we are a foliage HISMC, then our owner is an Instanced Foliage Actor,
							// if it is not, then we are just a "regular" HISMC
							AInstancedFoliageActor* InstancedFoliageActor = Cast<AInstancedFoliageActor>(HISMC->GetOwner());
							if (!IsValid(InstancedFoliageActor))
								return;

							UFoliageType *FoliageType = InstancedFoliageActor->GetLocalFoliageTypeForSource(FoliageSM);
							if (!IsValid(FoliageType))
								return;
#if WITH_EDITOR
							// Clean up the instances previously generated for that component
							InstancedFoliageActor->DeleteInstancesForComponent(ParentComponent, FoliageType);

							// Remove the foliage type if it doesn't have any more instances
							if(HISMC->GetInstanceCount() == 0)
								InstancedFoliageActor->RemoveFoliageType(&FoliageType, 1);

							bDidModifyFoliage = true;
#endif
						}

						// // do not delete FISMC that still have instances left
						// // as we have cleaned up our instances before, these have been hand-placed
						// if (HISMC->GetInstanceCount() > 0)
						bDestroyComponent = false;

						OutputObject.OutputComponents[Index] = nullptr;
					}
				}

				if (bDestroyComponent)
				{
					USceneComponent* SceneComponent = Cast<USceneComponent>(Component);
					if (IsValid(SceneComponent))
					{
						// Remove from its actor first
						if (SceneComponent->GetOwner())
						{
							SceneComponent->UnregisterComponent();
							SceneComponent->GetOwner()->RemoveOwnedComponent(SceneComponent);
						}

						// Detach from its parent component if attached
						SceneComponent->DetachFromComponent(FDetachmentTransformRules::KeepRelativeTransform);						
						SceneComponent->DestroyComponent();

						bDidDestroyObjects = true;

						OutputObject.OutputComponents[Index] = nullptr;
					}
				}
			}

			if (IsValid(OutputObject.OutputObject))
			{
				// For actors we detach them first and then destroy
				AActor* Actor = Cast<AActor>(OutputObject.OutputObject);
				UHoudiniLandscapePtr* LandscapePtr = Cast<UHoudiniLandscapePtr>(OutputObject.OutputObject);
				if (LandscapePtr)
				{
					Actor = LandscapePtr->GetRawPtr();
				}

				if (Actor)
				{
					Actor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
					Actor->Destroy();

					bDidDestroyObjects = true;
				}
				else
				{
// Technically this should be WITH_METADATA but it's 5.6 only..
#if WITH_EDITORONLY_DATA
					// ... if not an actor, destroy the object if it is a temp object created by the owning
					// HoudiniAssetComponent. Don't delete anything if we don't have a valid component GUID.
					if (IsValid(OutputObject.OutputObject) && !OutputObject.OutputObject->HasAnyFlags(RF_Transient) &&
						!ComponentGuidString.IsEmpty() && !OutputObjectsToDelete.Contains(OutputObject.OutputObject))
					{
						// Only delete if the object has metadata indicating it is a plugin created temp object
						UPackage* const Package = OutputObject.OutputObject->GetOutermost();
						if (IsValid(Package))
						{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 6
							FMetaData& MetaData = Package->GetMetaData();
#else
							UMetaData* const MetaData = Package->GetMetaData();
							if (IsValid(MetaData))
#endif
							{
								// Check for HAPI_UNREAL_PACKAGE_META_TEMP_GUID in the package metadata to confirm that
								// this is a temp package, and then ensure that the component GUID in the package metadata
								// for the object matches the GUID of the owning HAC
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 6
								if (MetaData.RootMetaDataMap.Contains(HAPI_UNREAL_PACKAGE_META_TEMP_GUID))
#else
								if (MetaData->RootMetaDataMap.Contains(HAPI_UNREAL_PACKAGE_META_TEMP_GUID))
#endif
								{
									FString TempGUID;
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 6
									TempGUID = MetaData.RootMetaDataMap.FindChecked(HAPI_UNREAL_PACKAGE_META_TEMP_GUID);
#else
									TempGUID = MetaData->RootMetaDataMap.FindChecked(HAPI_UNREAL_PACKAGE_META_TEMP_GUID);
#endif
									TempGUID.TrimStartAndEndInline();
									if (!TempGUID.IsEmpty())
									{
										// PackageComponentGuidString will be the empty string if the object does not
										// have the HAPI_UNREAL_PACKAGE_META_COMPONENT_GUID metadata key in the package
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 6
										const FString PackageComponentGuidString = MetaData.GetValue(OutputObject.OutputObject, HAPI_UNREAL_PACKAGE_META_COMPONENT_GUID);
#else
										const FString PackageComponentGuidString = MetaData->GetValue(OutputObject.OutputObject, HAPI_UNREAL_PACKAGE_META_COMPONENT_GUID);
#endif
										if (!PackageComponentGuidString.IsEmpty() && PackageComponentGuidString == ComponentGuidString)
											OutputObjectsToDelete.Add(OutputObject.OutputObject);
									}
								}
							}
						}
					}
#endif
					OutputObject.OutputObject = nullptr;
				}
			}
		}
	}

	ResultOutputs.Empty();

	if (bDidDestroyObjects)
		FHoudiniEngineRuntimeUtils::TryCollectGarbage();
	
	// Delete the output objects we found
	if (OutputObjectsToDelete.Num() > 0)
	{
		TArray<UObject*> ObjectsToDelete(OutputObjectsToDelete.Array());
		FHoudiniEngineRuntimeUtils::SafeDeleteObjects(ObjectsToDelete);
	}

#if WITH_EDITOR
	if (bDidModifyFoliage)
	{
		// Repopulate the foliage types in the foliage mode UI if foliage mode is active
		// There is a helper function in FHoudiniEngineUtils for this, but we cannot access it from this module.
		// TODO: refactor?
		FEditorModeTools& EditorModeTools = GLevelEditorModeTools();
		if (EditorModeTools.IsModeActive(FBuiltinEditorModes::EM_Foliage))
		{
			EditorModeTools.DeactivateMode(FBuiltinEditorModes::EM_Foliage);
			EditorModeTools.ActivateMode(FBuiltinEditorModes::EM_Foliage);
		}
	}
#endif
}

EPDGWorkResultState
FTOPWorkResultObject::GetState() const
{
	return State;
}

void FTOPWorkResultObject::SetState(EPDGWorkResultState NewState)
{
	State = NewState;

	if(TOPNode)
		TOPNode->SetWorkItemsDirty();
}

void FTOPWorkResultObject::DestroyResultOutputsAndRemoveOutputActor(const FGuid& InHoudiniComponentGuid)
{
	DestroyResultOutputs(InHoudiniComponentGuid);
	GetOutputActorOwner().DestroyOutputActor();
}

bool
FOutputActorOwner::CreateOutputActor(UWorld* InWorld, UHoudiniPDGAssetLink* InAssetLink, AActor *InParentActor, const FName& InName)
{
	// InAssetLink and InWorld must not be null
	if (!IsValid(InAssetLink))
	{
		HOUDINI_LOG_ERROR(TEXT("[FTOPWorkResultObject::CreateWorkResultActor]: InAssetLink is null!"));
		return false;
	}
	if (!IsValid(InWorld))
	{
		HOUDINI_LOG_ERROR(TEXT("[FTOPWorkResultObject::CreateWorkResultActor]: InWorld is null!"));
		return false;
	}

	AActor* AssetLinkActor = InAssetLink->GetOwnerActor();

	const bool bParentActorIsValid = IsValid(InParentActor);
	ULevel* LevelToSpawnIn = nullptr;
	if (bParentActorIsValid)
	{
		LevelToSpawnIn = InParentActor->GetLevel();
	}
	else
	{
		// Get the level containing the asset link's actor
		if (IsValid(AssetLinkActor))
			LevelToSpawnIn = AssetLinkActor->GetLevel();
	}

	// Fallback to InWorld's current level
	UWorld* WorldToSpawnIn = nullptr;
	if (!LevelToSpawnIn || !IsValid(LevelToSpawnIn))
	{
		LevelToSpawnIn = InWorld->GetCurrentLevel();
		WorldToSpawnIn = InWorld;
	}
	else
	{
		WorldToSpawnIn = LevelToSpawnIn->GetWorld();
	}

	if (!IsValid(WorldToSpawnIn) || !IsValid(LevelToSpawnIn))
	{
		HOUDINI_LOG_WARNING(
			TEXT("Could not determine level and world to spawn PDG output actor in: asset link %s, name %s"),
			*(InAssetLink->GetPathName()),
			*(InName.ToString()));
		return false;
	}
	
	FActorSpawnParameters SpawnParams;
#if WITH_EDITOR
	if (!LevelToSpawnIn->bUseExternalActors)
#endif
	{
		SpawnParams.Name = MakeUniqueObjectName(InWorld, AActor::StaticClass(), InName);
	}
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnParams.NameMode = FActorSpawnParameters::ESpawnActorNameMode::Requested;
	SpawnParams.OverrideLevel = LevelToSpawnIn;
	AActor *Actor = WorldToSpawnIn->SpawnActor<AActor>(SpawnParams);
	SetOutputActor(Actor);
#if WITH_EDITOR
	FHoudiniEngineRuntimeUtils::SetActorLabel(Actor, InName.ToString());
#endif
	
	// Set the actor transform: create a root component if it does not have one
	USceneComponent* RootComponent = Actor->GetRootComponent();
	if (!IsValid(RootComponent))
	{
		RootComponent = NewObject<USceneComponent>(Actor, USceneComponent::StaticClass(), NAME_None, RF_Transactional);

		// Change the creation method so the component is listed in the details panels
		FHoudiniEngineRuntimeUtils::AddOrSetAsInstanceComponent(RootComponent);
		Actor->SetRootComponent(RootComponent);
		RootComponent->OnComponentCreated();
	}
	
	RootComponent->SetVisibility(true);

	// Match the parent root's mobility so that PDG output actors can be attached without
	// forcing static output hierarchies to become movable.
	const USceneComponent* ParentRootComponent = IsValid(InParentActor) ? InParentActor->GetRootComponent() : nullptr;
	const EComponentMobility::Type RootMobility = IsValid(ParentRootComponent)
		? static_cast<EComponentMobility::Type>(ParentRootComponent->Mobility)
		: EComponentMobility::Static;
	RootComponent->SetMobility(RootMobility);

	const FVector ActorSpawnLocation = InParentActor ? InParentActor->GetActorLocation() : FVector::ZeroVector;
	const FRotator ActorSpawnRotator = InParentActor ? InParentActor->GetActorRotation() : FRotator::ZeroRotator;
	// Static and stationary components may only be moved before they are registered.
	Actor->SetActorLocation(ActorSpawnLocation);
	Actor->SetActorRotation(ActorSpawnRotator);
	if (!RootComponent->IsRegistered())
		RootComponent->RegisterComponent();

#if WITH_EDITOR
	if ((InParentActor && IsValid(InParentActor)) && InParentActor->GetLevel() == LevelToSpawnIn)
	{
		Actor->SetFolderPath(InParentActor->GetFolderPath());
		Actor->AttachToActor(InParentActor, FAttachmentTransformRules::KeepWorldTransform);
	}
	else if (IsValid(AssetLinkActor) && AssetLinkActor->GetLevel() == LevelToSpawnIn)
	{
		Actor->SetFolderPath(*FString::Format(
			TEXT("{0}/{1}_Output"), 
			{ FStringFormatArg(AssetLinkActor->GetFolderPath().ToString()), FStringFormatArg(AssetLinkActor->GetActorLabel()) }
		));
	}
	else
	{
		Actor->SetFolderPath(*FString::Format(TEXT("{0}_Output"), { FStringFormatArg(InAssetLink->GetName()) }));
	}
#else
	if(IsValid(InParentActor) && InParentActor->GetLevel() == LevelToSpawnIn)
	{
		OutputActor->AttachToActor(InParentActor, FAttachmentTransformRules::KeepWorldTransform);
	}
#endif

	return true;
}

bool
FOutputActorOwner::DestroyOutputActor()
{
	bool bDestroyed = false;
	AActor *Actor = GetOutputActor();
	if (IsValid(Actor))
	{
		// Detach from parent before destroying the actor
		Actor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		Actor->Destroy();

		bDestroyed = true;
	}

	SetOutputActor(nullptr);

	return bDestroyed;
}
