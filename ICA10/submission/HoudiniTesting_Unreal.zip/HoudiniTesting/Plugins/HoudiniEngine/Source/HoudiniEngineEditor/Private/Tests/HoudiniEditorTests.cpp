/*
* Copyright (c) <2021> Side Effects Software Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. The name of Side Effects Software may not be used to endorse or
*    promote products derived from this software without specific prior
*    written permission.
*
* THIS SOFTWARE IS PROVIDED BY SIDE EFFECTS SOFTWARE "AS IS" AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
* NO EVENT SHALL SIDE EFFECTS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "HoudiniEditorTests.h"

#include "HoudiniEditorEquivalenceUtils.h"
#include "HoudiniPublicAPIAssetWrapper.h"

#include "FileHelpers.h"

#if WITH_DEV_AUTOMATION_TESTS

#include "HoudiniEditorTestUtils.h"
#include "HoudiniAsset.h"
#include "HoudiniAssetComponent.h"

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 3
	#include "HAL/FileManager.h"
#else
	#include "Core/Public/HAL/FileManager.h"
#endif
#include "Misc/AutomationTest.h"


IMPLEMENT_SIMPLE_HOUDINI_AUTOMATION_TEST(HoudiniEditorEvergreenTest, "Houdini.Editor.Screenshots.EvergreenScreenshots", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

bool HoudiniEditorEvergreenTest::RunTest(const FString & Parameters)
{
	// Don't do screenshot tests because they fail a lot. Leaving the code here for now.
#if 0
	FHoudiniEditorTestUtils::InitializeTests(this, [this]
	{
		FHoudiniEditorTestUtils::GetMainFrameWindow()->Resize(FHoudiniEditorTestUtils::GDefaultEditorSize);

		FHoudiniEditorTestUtils::InstantiateAsset(this, TEXT("/Game/TestHDAs/Evergreen"), 
		[this](UHoudiniPublicAPIAssetWrapper* InAssetWrapper, const bool IsSuccessful)
		{
			// Entire editor screenshots don't work well with build machines. Disable for now.
			// FHoudiniEditorTestUtils::TakeScreenshotEditor(this, TEXT("EverGreen_EntireEditor.png"), FHoudiniEditorTestUtils::ENTIRE_EDITOR, FHoudiniEditorTestUtils::GDefaultEditorSize);
			FHoudiniEditorTestUtils::TakeScreenshotEditor(this, TEXT("EverGreen_Details.png"), FHoudiniEditorTestUtils::DETAILS_WINDOW, FVector2D(400, 1000));
			FHoudiniEditorTestUtils::TakeScreenshotEditor(this, TEXT("EverGreen_EditorViewport.png"), FHoudiniEditorTestUtils::VIEWPORT, FVector2D(640, 360));
		});
	});
#endif
	return true;
}

// Tests whether or not we need to update the FHoudiniEditorEquivalenceUtils::IsEquivalent function
IMPLEMENT_SIMPLE_HOUDINI_AUTOMATION_TEST(HoudiniEditorDuplicateTest, "Houdini.Editor.Random.DuplicateTest", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

bool HoudiniEditorDuplicateTest::RunTest(const FString & Parameters)
{
	// Really force editor size
	FHoudiniEditorTestUtils::InitializeTests(this, [this]
	{
		FHoudiniEditorTestUtils::InstantiateAsset(this, TEXT("/Game/TestHDAs/Evergreen"), 
		[this](UHoudiniPublicAPIAssetWrapper* InAssetWrapper, const bool IsSuccessful)
		{
			FHoudiniEditorTestUtils::InstantiateAsset(this, TEXT("/Game/TestHDAs/Evergreen"), 
			[this, InAssetWrapper](UHoudiniPublicAPIAssetWrapper* InAssetWrapper2, const bool IsSuccessful2)
			{
				// TODO: Only compare cookables?
				bool bIsEquivalent = true;
				if (!FHoudiniEditorEquivalenceUtils::IsEquivalent(InAssetWrapper->GetHoudiniCookable(), InAssetWrapper2->GetHoudiniCookable()))
				{
					bIsEquivalent = false;
				}

				if (!FHoudiniEditorEquivalenceUtils::IsEquivalent(InAssetWrapper->GetHoudiniAssetComponent(), InAssetWrapper2->GetHoudiniAssetComponent()))
				{
					bIsEquivalent = false;
				}

				if (bIsEquivalent)
				{
					return true;
				}
				else
				{
					this->AddError("Duplication is not Equivalent! This is a sign we need to update the FHoudiniEditorEquivalenceUtils::IsEquivalent function");
					return false;
				}
			
			});
		});
	});
	
	return true;
}

IMPLEMENT_SIMPLE_HOUDINI_AUTOMATION_TEST(HoudiniEditorEvergreenEquivalenceTest, "Houdini.Editor.Random.EvergreenEquivalence", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

bool HoudiniEditorEvergreenEquivalenceTest::RunTest(const FString & Parameters)
{
#if !DISABLE_LANDSCAPE_RELATED_TEST
	// Really force editor size
	FHoudiniEditorTestUtils::InitializeTests(this, [this]
	{
		const FString MapName = TEXT("RandomTests");
		const FString ActorName = TEXT("EvergreenEquivalence");
		const FString HDAAssetPath = TEXT("/Game/TestHDAs/Evergreen");
		const FHoudiniActorTestSettings Settings = {};

		FHoudiniEditorTestUtils::RunOrSetupDifferentialTest(this, MapName, HDAAssetPath, ActorName, Settings, [this](bool IsSuccessful)
		{
			
		});
	});
#endif
	return true;
}

IMPLEMENT_SIMPLE_HOUDINI_AUTOMATION_TEST(HoudiniEditorRandomEquivalenceTest, "Houdini.Editor.Random.RandomEquivalence", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

bool HoudiniEditorRandomEquivalenceTest::RunTest(const FString & Parameters)
{
#if !DISABLE_LANDSCAPE_RELATED_TEST
	// Really force editor size
	FHoudiniEditorTestUtils::InitializeTests(this, [this]
	{
		FHoudiniActorTestSettings Settings = {};
		Settings.bEnableCurveEditing = true;
		FHoudiniEditorTestUtils::RunOrSetupDifferentialTest(this, TEXT("RandomTests"), TEXT("/Game/TestHDAs/Random/simple_curve"), TEXT("simple_curve"), Settings, [this](bool IsSuccessful)
		{
			FHoudiniEditorTestUtils::RunOrSetupDifferentialTest(this, TEXT("RandomTests"), TEXT("/Game/TestHDAs/Random/simple_heightfield"), TEXT("simple_heightfield"), {}, [this](bool IsSuccessful)
			{

			});
		});
	});
#endif
	return true;
}

#endif
