/*
* Copyright (c) <2021> Side Effects Software Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. The name of Side Effects Software may not be used to endorse or
*    promote products derived from this software without specific prior
*    written permission.
*
* THIS SOFTWARE IS PROVIDED BY SIDE EFFECTS SOFTWARE "AS IS" AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
* NO EVENT SHALL SIDE EFFECTS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "DetailCategoryBuilder.h"
#include "IDetailCustomization.h"

class FHoudiniRuntimeSettingsDetails : public IDetailCustomization
{
public:

	/** Constructor. **/
	FHoudiniRuntimeSettingsDetails();

	/** Destructor. **/
	virtual ~FHoudiniRuntimeSettingsDetails();

	/** IDetailCustomization methods. **/
public:

	virtual void CustomizeDetails(IDetailLayoutBuilder & DetailBuilder) override;

public:

	/** Create an instance of this detail layout class. **/
	static TSharedRef< IDetailCustomization > MakeInstance();

protected:

	/** Used to create Houdini version entry. **/
	void CreateHoudiniEntry(
		const FText & EntryName, IDetailCategoryBuilder & DetailCategoryBuilder,
		int32 VersionMajor, int32 VersionMinor, int32 VersionBuild, int32 VersionPatch);

	/** Used to create Houdini Engine version entry. **/
	void CreateHoudiniEngineEntry(
		const FText & EntryName, IDetailCategoryBuilder & DetailCategoryBuilder,
		int32 VersionMajor, int32 VersionMinor, int32 VersionApi);

	/** Used to create libHAPI dynamic library path entry. **/
	void CreateHAPILibraryPathEntry(
		const FString & LibHAPIPath, IDetailCategoryBuilder & DetailCategoryBuilder);

	/** Used to create libHAPI license information entry. **/
	void CreateHAPILicenseEntry(
		const FString & LibHAPILicense, IDetailCategoryBuilder & DetailCategoryBuilder);
};
