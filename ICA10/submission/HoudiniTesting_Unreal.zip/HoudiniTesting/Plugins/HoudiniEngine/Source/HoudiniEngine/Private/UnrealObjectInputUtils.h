/*
* Copyright (c) <2023> Side Effects Software Inc.
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. The name of Side Effects Software may not be used to endorse or
*    promote products derived from this software without specific prior
*    written permission.
*
* THIS SOFTWARE IS PROVIDED BY SIDE EFFECTS SOFTWARE "AS IS" AND ANY EXPRESS
* OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
* NO EVENT SHALL SIDE EFFECTS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
* OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "CoreTypes.h"
#include "Containers/Array.h"
#include "Containers/Set.h"
#include "Misc/Optional.h"
#include "UObject/NameTypes.h"

#include "HAPI/HAPI_Common.h"

#include "UnrealObjectInputManager.h"
#include "UnrealObjectInputRuntimeTypes.h"


struct FHoudiniInputObjectSettings;
// UE forward declarations
class UObject;
class ULandscapeSplinesComponent;


struct HOUDINIENGINE_API FUnrealObjectInputUtils
{
	public:
		// Helper that checks that the input entry associated with InIdentifier exists, the HAPI nodes for are valid and
		// the entry is not marked as dirty.
		static bool NodeExistsAndIsNotDirty(const FUnrealObjectInputIdentifier& InIdentifier, FUnrealObjectInputHandle& OutHandle);

		// Returns true if the HAPI nodes referenced by the input reference node of InHandle are valid (exist).
		static bool AreReferencedHAPINodesValid(const FUnrealObjectInputHandle& InHandle);

		// Add an entry for an input to track and reference count in the manager.
		// Returns true on success and sets OutHandle to point to the entry.
		static bool AddNodeOrUpdateNode(
			const FUnrealObjectInputIdentifier& InIdentifier,
			const int32 NodeId,
			FUnrealObjectInputHandle& OutHandle,
			const int32 InObjectNodeId,
			TSet<FUnrealObjectInputHandle> const* const InReferencedNodes,
			const bool& bInputNodesCanBeDeleted,
			const TOptional<int32> InReferencesConnectToNodeId=TOptional<int32>());

		// Helper to set the CanBeDeleted property on the input object associated with InHandle
		static bool UpdateInputNodeCanBeDeleted(const FUnrealObjectInputHandle& InHandle, const bool& bCanBeDeleted);

		// Helper to set the references on a reference node
		static bool SetReferencedNodes(const FUnrealObjectInputHandle& InRefNodeHandle, const TSet<FUnrealObjectInputHandle>& InReferencedNodes);

		// Helper to get the references on a reference node
		static bool GetReferencedNodes(const FUnrealObjectInputHandle& InRefNodeHandle, TSet<FUnrealObjectInputHandle>& OutReferencedNodes);

		// Helper to set an object_merge SOP's xformtype to "Into Specified Object" and the xformpath to the manager's
		// WorldOrigin null.
		static bool SetObjectMergeXFormTypeToWorldOrigin(const HAPI_NodeId& InObjMergeNodeId);

		// Helper to set the node that references connect to (such as a Merge SOP) for a reference node in the input system	
		static bool SetReferencesNodeConnectToNodeId(const FUnrealObjectInputHandle& InHandle, HAPI_NodeId InNodeId);

		// Helper to connect a reference node's referenced nodes to its merge SOP
		static bool ConnectReferencedNodesToMerge(const FUnrealObjectInputIdentifier& InRefNodeIdentifier);

		// Helper to create a SOP/merge for merging InReferencedNodes.
		static bool CreateOrUpdateReferenceInputMergeNode(
			const FUnrealObjectInputIdentifier& InIdentifier,
			const TSet<FUnrealObjectInputHandle>& InReferencedNodes,
			FUnrealObjectInputHandle& OutHandle,
			bool bInConnectReferencedNode,
			bool bInputNodesCanBeDeleted);

		// Add a named modifier chain to the input node. Returns false if the chain was not added (if it existed already, for example)
		static bool AddModifierChain(const FUnrealObjectInputHandle& InHandle, FName InChainName, int32 InNodeIdToConnectTo);

		// Set the node that the first node of the chain connects to.
		static bool SetModifierChainNodeToConnectTo(const FUnrealObjectInputHandle& InHandle, FName InChainName, int32 InNodeToConnectTo);

		// Returns true if the named modifier chain exists on the node.
		static bool DoesModifierChainExist(const FUnrealObjectInputHandle& InHandle, FName InChainName);

		// Returns the input node id of the named modifier chain on the node. Returns < 0 if the chain does not exist.
		static HAPI_NodeId GetInputNodeOfModifierChain(const FUnrealObjectInputHandle& InHandle, FName InChainName);

		// Returns the output node id of the named modifier chain on the node. Returns < 0 if the chain does not exist.
		static HAPI_NodeId GetOutputNodeOfModifierChain(const FUnrealObjectInputHandle& InHandle, FName InChainName);

		// Removed the named modifier chain. Returns true if the chain existed and was removed.
		static bool RemoveModifierChain(const FUnrealObjectInputHandle& InHandle, FName InChainName);

		// Destroy the given modifier in the named chain. This deletes the modifier, so InModifierToDestroy will be invalid after a successful call to this function.
		static bool DestroyModifier(const FUnrealObjectInputHandle& InHandle, FName InChainName, FUnrealObjectInputModifier* InModifierToDestroy);

		// Find and return the first modifier of class T on the node identified by InIdentifier. Returns null if it has
		// no such modifier.
		static FUnrealObjectInputModifier* FindFirstModifierOfType(const FUnrealObjectInputHandle& InHandle, FName InChainName, EUnrealObjectInputModifierType InModifierType);

		// Add a modifier of class T to the node identified by InIdentifier if it does not already have a modifier
		// of that class. Return the newly created and added (or existing) modifier.
		template<class T, class... Args>
		static T* CreateAndAddModifier(const FUnrealObjectInputHandle& InHandle, FName InChainName, Args... ConstructorArguments);

		// Call FUnrealInputObjectModifier::Update() on all modifiers in the chain.
		static bool UpdateModifiers(const FUnrealObjectInputHandle& InHandle, FName InChainName);

		// Call FUnrealInputObjectModifier::Update() on all modifiers on the node identified by InIdentifier.
		static bool UpdateAllModifierChains(const FUnrealObjectInputHandle& InHandle);
};


template<class T, class... Args>
T* FUnrealObjectInputUtils::CreateAndAddModifier(const FUnrealObjectInputHandle& InHandle, const FName InChainName, Args... ConstructorArguments)
{
	FUnrealObjectInputNode* Node = nullptr;
	if (!InHandle.IsValid() || !FUnrealObjectInputManager::Get().GetNode(InHandle, Node) || !Node)
		return nullptr;

	return Node->CreateAndAddModifier<T>(InChainName, ConstructorArguments...);
}
