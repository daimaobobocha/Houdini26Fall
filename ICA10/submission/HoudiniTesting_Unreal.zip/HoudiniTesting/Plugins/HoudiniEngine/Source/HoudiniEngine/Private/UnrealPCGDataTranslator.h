/*
 * Copyright (c) <2021> Side Effects Software Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. The name of Side Effects Software may not be used to endorse or
 *    promote products derived from this software without specific prior
 *    written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY SIDE EFFECTS SOFTWARE "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL SIDE EFFECTS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <PCGData.h>

#include "HoudiniPCGDataObject.h"
#include "UnrealObjectInputRuntimeTypes.h"
#include "HAPI/HAPI_Common.h"
#include "UObject/NameTypes.h"

class UPCGPointData;
class FUnrealObjectInputHandle;
class UHoudiniPCGDataObject;

struct HOUDINIENGINE_API FUnrealPCGDataTranslator
{
public:
    static bool CreateInputNodeForPCGData(
        UHoudiniPCGDataCollection* PCGData,
            const FString& InputNodeName,
            FUnrealObjectInputHandle& OutHandle,
            bool bInputNodesCanBeDeleted);

protected:
    static FUnrealObjectInputHandle CreateInputNodeForPCGAttrData(const FString& InputNodeName, UHoudiniPCGDataCollection* InputData, bool bInputNodesCanBeDeleted);
    static TArray<FUnrealObjectInputHandle> CreateInputNodeForPCGSplineData(const FString& InputNodeName, UHoudiniPCGDataCollection* InputData, bool bInputNodesCanBeDeleted);
    static FUnrealObjectInputHandle CreateInputNodeForPCGSplineData(const FString& InputNodeName, UHoudiniPCGDataObject* InputData, bool bInputNodesCanBeDeleted);

    static void SetAttributes(UHoudiniPCGDataObject* PCGDataObject, HAPI_NodeId Node, HAPI_PartId PartId,  HAPI_AttributeOwner Owner);

    static void SendToHoudini(UHoudiniPCGDataAttributeFloat* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeInt* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeDouble* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeString* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeInt64* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeVector2d* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeVector3d* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeVector4d* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeQuat* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeSoftObjectPath* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);
    static void SendToHoudini(UHoudiniPCGDataAttributeSoftClassPath* Data, HAPI_NodeId InputNodeId, HAPI_PartId PartId, HAPI_AttributeOwner Owner);

    static FUnrealObjectInputHandle CreateInputNode(const FString& Name, UObject* Object, bool bInputNodesCanBeDeleted);

};
